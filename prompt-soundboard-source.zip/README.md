# Prompt Soundboard

A browser soundboard that turns spoken or typed prompts into nine numbered audio samples. Built with React, TypeScript, Vite, and a bundled Transformers.js / ONNX runtime.

## Run locally

Use Node.js 24 or newer and pnpm (the package.json records the original package-manager version).

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open the localhost URL printed by Vite. Hold **0** to record a voice prompt; release it to generate sounds. Use **1–9** to play populated slots. You can also enter a text prompt.

The first generation downloads model weights from Hugging Face, including a roughly 656 MB sound model. Inference runs in the browser; microphone access requires localhost or HTTPS. Samples are stored in the browser's Origin Private File System. Existing samples on the hosted site remain associated with that site's origin and do not transfer to localhost.

## Check and build

```sh
pnpm typecheck
pnpm build
pnpm preview
```

The static output is in `dist/`. `.openai/hosting.json` and the postbuild script preserve the existing ChatGPT Sites hosting configuration. You can host the static output separately; local development does not need a ChatGPT API key.

## GitHub

The repository preserves the original source history and has no GitHub remote configured. Create an empty GitHub repository, then connect it:

```sh
git add README.md .gitignore
git commit -m "Document local development and GitHub setup"
git remote add origin https://github.com/YOUR-USERNAME/prompt-soundboard.git
git push -u origin main
```

Dependencies, build output, local environment files, and editor settings are ignored. The bundled Transformers.js license is retained under `public/vendor/transformers/`.
