import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  formatDuration,
  pickRecordingMimeType,
  recordedBlobToMonoPcm,
} from "./lib/audio";
import {
  deleteSample,
  loadSamples,
  requestPersistentStorage,
  saveSample,
  StoredSample,
  supportsOpfs,
} from "./lib/opfs";

type SampleView = Omit<StoredSample, "blob"> & {
  url: string;
};

type Activity = "idle" | "recording" | "transcribing" | "generating";
type StorageState =
  | "checking"
  | "persistent"
  | "best-effort"
  | "unavailable";

type WorkerMessage = {
  type:
    | "status"
    | "model-progress"
    | "generation-progress"
    | "transcript"
    | "sample"
    | "generation-complete"
    | "error";
  requestId?: string;
  message?: string;
  stage?: "speech" | "sound";
  file?: string;
  progress?: number;
  text?: string;
  slot?: number;
  prompt?: string;
  variant?: string;
  duration?: number;
  wav?: ArrayBuffer;
  count?: number;
};

const SLOT_NUMBERS = Array.from({ length: 9 }, (_, index) => index + 1);
const GENERATION_DURATION = 3;
const MAX_RECORDING_MS = 15_000;

function isEditableTarget(target: EventTarget | null): boolean {
  return (
    target instanceof HTMLInputElement ||
    target instanceof HTMLTextAreaElement ||
    target instanceof HTMLSelectElement ||
    (target instanceof HTMLElement && target.isContentEditable)
  );
}

function slotFromKeyboardCode(code: string): number | null {
  const match = /^(?:Digit|Numpad)([1-9])$/.exec(code);
  return match ? Number(match[1]) : null;
}

function TrashIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7m4 4v5m4-5v5" />
    </svg>
  );
}

function MicIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <rect x="9" y="3" width="6" height="11" rx="3" />
      <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3m-4 0h8" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m9 7 8 5-8 5V7Z" />
    </svg>
  );
}

function Waveform({ slot }: { slot: number }) {
  return (
    <span className="waveform" aria-hidden="true">
      {Array.from({ length: 18 }, (_, index) => (
        <i
          key={index}
          style={
            {
              "--bar-height": `${18 + ((index * 19 + slot * 13) % 68)}%`,
            } as React.CSSProperties
          }
        />
      ))}
    </span>
  );
}

export default function Home() {
  const [samples, setSamples] = useState<SampleView[]>([]);
  const [activity, setActivity] = useState<Activity>("idle");
  const [status, setStatus] = useState("Ready for a voice prompt.");
  const [error, setError] = useState("");
  const [prompt, setPrompt] = useState("");
  const [storageState, setStorageState] =
    useState<StorageState>("checking");
  const [storageLoaded, setStorageLoaded] = useState(false);
  const [modelProgress, setModelProgress] = useState(0);
  const [generationProgress, setGenerationProgress] = useState<
    Record<number, number>
  >({});
  const [playingSlot, setPlayingSlot] = useState<number | null>(null);
  const [pendingDeleteSlot, setPendingDeleteSlot] = useState<number | null>(
    null,
  );

  const workerRef = useRef<Worker | null>(null);
  const samplesRef = useRef<SampleView[]>([]);
  const actionRef = useRef<(text: string) => void>(() => undefined);
  const saveChainRef = useRef(Promise.resolve());
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const recordingStartedAtRef = useRef(0);
  const recordingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const zeroHeldRef = useRef(false);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const deleteDialogRef = useRef<HTMLDialogElement | null>(null);

  const sampleBySlot = useMemo(
    () => new Map(samples.map((sample) => [sample.slot, sample])),
    [samples],
  );
  const emptySlots = SLOT_NUMBERS.filter((slot) => !sampleBySlot.has(slot));
  const isBusy = activity !== "idle";

  useEffect(() => {
    samplesRef.current = samples;
  }, [samples]);

  const stopPlayback = useCallback(() => {
    currentAudioRef.current?.pause();
    currentAudioRef.current = null;
    setPlayingSlot(null);
  }, []);

  const playSlot = useCallback(
    (slot: number) => {
      const sample = samplesRef.current.find((item) => item.slot === slot);
      if (!sample) {
        setStatus(`Pad ${slot} is empty.`);
        return;
      }

      stopPlayback();
      const audio = new Audio(sample.url);
      currentAudioRef.current = audio;
      setPlayingSlot(slot);
      setStatus(`Playing pad ${slot}: ${sample.variant}.`);
      audio.addEventListener(
        "ended",
        () => {
          if (currentAudioRef.current === audio) {
            currentAudioRef.current = null;
            setPlayingSlot(null);
            setStatus("Ready.");
          }
        },
        { once: true },
      );
      audio.play().catch(() => {
        setPlayingSlot(null);
        setError("The browser blocked audio playback. Try the pad again.");
      });
    },
    [stopPlayback],
  );

  const generateForPrompt = useCallback((text: string) => {
    const normalized = text.trim();
    if (!normalized || !workerRef.current) return;

    const occupied = new Set(samplesRef.current.map((sample) => sample.slot));
    const targets = SLOT_NUMBERS.filter((slot) => !occupied.has(slot));

    if (targets.length === 0) {
      setError(
        "All nine pads are occupied. Delete a pad with its trash button before generating another sound.",
      );
      setStatus("No empty pads available.");
      return;
    }

    setError("");
    setPrompt(normalized);
    setActivity("generating");
    setGenerationProgress({});
    setModelProgress(0);
    setStatus(
      `Generating ${targets.length} local sound${targets.length === 1 ? "" : "s"} into empty pads…`,
    );
    workerRef.current.postMessage({
      type: "generate",
      requestId: crypto.randomUUID(),
      prompt: normalized,
      slots: targets,
      duration: GENERATION_DURATION,
    });
  }, []);

  useEffect(() => {
    actionRef.current = generateForPrompt;
  }, [generateForPrompt]);

  useEffect(() => {
    const worker = new Worker("/ai.worker.js", {
      type: "module",
    });
    workerRef.current = worker;

    worker.addEventListener(
      "message",
      async (event: MessageEvent<WorkerMessage>) => {
        const data = event.data;

        if (data.type === "status" && data.message) {
          setStatus(data.message);
          return;
        }

        if (data.type === "model-progress") {
          setModelProgress(Math.max(0, Math.min(data.progress ?? 0, 1)));
          return;
        }

        if (
          data.type === "generation-progress" &&
          data.slot &&
          typeof data.progress === "number"
        ) {
          setGenerationProgress((current) => ({
            ...current,
            [data.slot as number]: data.progress as number,
          }));
          return;
        }

        if (data.type === "transcript" && data.text) {
          setPrompt(data.text);
          actionRef.current(data.text);
          return;
        }

        if (
          data.type === "sample" &&
          data.slot &&
          data.prompt &&
          data.variant &&
          data.duration &&
          data.wav
        ) {
          const wav = data.wav;
          const slot = data.slot;
          const samplePrompt = data.prompt;
          const variant = data.variant;
          const duration = data.duration;

          saveChainRef.current = saveChainRef.current.then(async () => {
            const blob = new Blob([wav], { type: "audio/wav" });
            const metadata = await saveSample(
              {
                slot,
                prompt: samplePrompt,
                variant,
                createdAt: new Date().toISOString(),
                duration,
              },
              blob,
            );
            const url = URL.createObjectURL(blob);
            setSamples((current) => [
              ...current.filter((sample) => sample.slot !== slot),
              { ...metadata, url },
            ].sort((a, b) => a.slot - b.slot));
          });
          return;
        }

        if (data.type === "generation-complete") {
          try {
            await saveChainRef.current;
            setStatus(
              `${data.count ?? "All"} sound${data.count === 1 ? "" : "s"} generated and saved privately.`,
            );
          } catch (saveError) {
            setError(
              saveError instanceof Error
                ? saveError.message
                : "A generated sample could not be saved to OPFS.",
            );
          } finally {
            setActivity("idle");
            setModelProgress(0);
          }
          return;
        }

        if (data.type === "error") {
          setActivity("idle");
          setModelProgress(0);
          setError(
            data.message ??
              "The local AI model could not complete the request.",
          );
          setStatus("Ready to try again.");
        }
      },
    );

    worker.addEventListener("error", () => {
      setActivity("idle");
      setError("The local AI worker stopped unexpectedly. Reload to retry.");
    });

    return () => {
      worker.terminate();
      workerRef.current = null;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const restore = async () => {
      if (!supportsOpfs()) {
        setStorageState("unavailable");
        setStorageLoaded(true);
        setError(
          "This browser does not support OPFS. Use a current desktop Chrome or Edge browser.",
        );
        return;
      }

      try {
        const restored = await loadSamples();
        if (cancelled) return;
        setSamples(
          restored.map(({ blob, ...metadata }) => ({
            ...metadata,
            url: URL.createObjectURL(blob),
          })),
        );
        const persisted = await navigator.storage.persisted();
        setStorageState(persisted ? "persistent" : "best-effort");
      } catch (restoreError) {
        if (!cancelled) {
          setStorageState("unavailable");
          setError(
            restoreError instanceof Error
              ? restoreError.message
              : "Saved samples could not be loaded.",
          );
        }
      } finally {
        if (!cancelled) setStorageLoaded(true);
      }
    };

    void restore();
    return () => {
      cancelled = true;
      samplesRef.current.forEach((sample) => URL.revokeObjectURL(sample.url));
    };
  }, []);

  const stopRecording = useCallback(() => {
    if (recordingTimerRef.current) {
      clearTimeout(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    const recorder = mediaRecorderRef.current;
    if (recorder?.state === "recording") recorder.stop();
  }, []);

  const startRecording = useCallback(async () => {
    if (activity !== "idle" || mediaRecorderRef.current?.state === "recording") {
      return;
    }
    if (!storageLoaded || storageState === "unavailable") {
      setError("Private local storage must be available before recording.");
      return;
    }
    if (samplesRef.current.length >= 9) {
      setError(
        "All nine pads are occupied. Delete a pad before recording a new prompt.",
      );
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Microphone capture is not supported in this browser.");
      return;
    }

    setError("");
    stopPlayback();

    try {
      const persisted = await requestPersistentStorage();
      setStorageState(persisted ? "persistent" : "best-effort");

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      const mimeType = pickRecordingMimeType();
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      mediaStreamRef.current = stream;
      mediaRecorderRef.current = recorder;
      recordingChunksRef.current = [];
      recordingStartedAtRef.current = performance.now();

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data.size) recordingChunksRef.current.push(event.data);
      });

      recorder.addEventListener(
        "stop",
        async () => {
          stream.getTracks().forEach((track) => track.stop());
          mediaStreamRef.current = null;
          mediaRecorderRef.current = null;
          const elapsed = performance.now() - recordingStartedAtRef.current;

          if (elapsed < 300) {
            setActivity("idle");
            setStatus("Hold a little longer so I can hear the prompt.");
            return;
          }

          try {
            setActivity("transcribing");
            setStatus("Preparing speech for private transcription…");
            const blob = new Blob(recordingChunksRef.current, {
              type: recorder.mimeType,
            });
            recordingChunksRef.current = [];
            const pcm = await recordedBlobToMonoPcm(blob);
            workerRef.current?.postMessage(
              {
                type: "transcribe",
                requestId: crypto.randomUUID(),
                audio: pcm,
              },
              [pcm.buffer],
            );
          } catch (recordingError) {
            setActivity("idle");
            setError(
              recordingError instanceof Error
                ? recordingError.message
                : "The recording could not be processed.",
            );
          }
        },
        { once: true },
      );

      recorder.start(250);
      setActivity("recording");
      setStatus("Listening… release to generate.");
      recordingTimerRef.current = setTimeout(
        stopRecording,
        MAX_RECORDING_MS,
      );
    } catch (microphoneError) {
      setActivity("idle");
      mediaStreamRef.current?.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
      setError(
        microphoneError instanceof DOMException &&
          microphoneError.name === "NotAllowedError"
          ? "Microphone access was not granted. Enable it in browser settings and try again."
          : "The microphone could not be started.",
      );
    }
  }, [
    activity,
    storageLoaded,
    storageState,
    stopPlayback,
    stopRecording,
  ]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (isEditableTarget(event.target) || deleteDialogRef.current?.open) return;

      if (event.code === "Digit0" || event.code === "Numpad0") {
        event.preventDefault();
        if (!event.repeat && !zeroHeldRef.current) {
          zeroHeldRef.current = true;
          void startRecording();
        }
        return;
      }

      const slot = slotFromKeyboardCode(event.code);
      if (slot && !event.repeat) {
        event.preventDefault();
        playSlot(slot);
      }
    };

    const onKeyUp = (event: KeyboardEvent) => {
      if (
        (event.code === "Digit0" || event.code === "Numpad0") &&
        zeroHeldRef.current
      ) {
        event.preventDefault();
        zeroHeldRef.current = false;
        stopRecording();
      }
    };

    const stopHeldRecording = () => {
      if (zeroHeldRef.current) {
        zeroHeldRef.current = false;
        stopRecording();
      }
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", stopHeldRecording);
    document.addEventListener("visibilitychange", stopHeldRecording);

    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", stopHeldRecording);
      document.removeEventListener("visibilitychange", stopHeldRecording);
    };
  }, [playSlot, startRecording, stopRecording]);

  const requestDelete = (slot: number) => {
    setPendingDeleteSlot(slot);
    deleteDialogRef.current?.showModal();
  };

  const confirmDelete = async () => {
    if (!pendingDeleteSlot) return;
    const slot = pendingDeleteSlot;

    try {
      stopPlayback();
      await deleteSample(slot);
      setSamples((current) => {
        const removed = current.find((sample) => sample.slot === slot);
        if (removed) URL.revokeObjectURL(removed.url);
        return current.filter((sample) => sample.slot !== slot);
      });
      setStatus(`Pad ${slot} deleted. It is ready for a new sound.`);
    } catch (deleteError) {
      setError(
        deleteError instanceof Error
          ? deleteError.message
          : `Pad ${slot} could not be deleted.`,
      );
    } finally {
      setPendingDeleteSlot(null);
      deleteDialogRef.current?.close();
    }
  };

  const modelProgressPercent = Math.round(modelProgress * 100);

  return (
    <>
      <a className="skip-link" href="#sound-pads">
        Skip to sound pads
      </a>

      <header className="site-header">
        <a className="brand" href="#" aria-label="Prompt Soundboard home">
          <span className="brand-mark" aria-hidden="true">
            PS
          </span>
          <span>Prompt Soundboard</span>
        </a>
        <div className="header-status" aria-label="Application status">
          <span className="privacy-pill">
            <i aria-hidden="true" />
            Local processing
          </span>
          <span className={`storage-pill storage-${storageState}`}>
            {storageState === "persistent"
              ? "OPFS persistent"
              : storageState === "best-effort"
                ? "OPFS active"
                : storageState === "checking"
                  ? "Checking storage"
                  : "OPFS unavailable"}
          </span>
        </div>
      </header>

      <main>
        <section className="hero" aria-labelledby="main-title">
          <div className="hero-copy">
            <p className="eyebrow">Private, on-device audio lab</p>
            <h1 id="main-title">
              Say it. <em>Shape it.</em>
              <br />
              Play it.
            </h1>
            <p className="intro">
              Hold zero, describe a sound, then release. Nine local AI
              variations land on keys one through nine and stay there until
              you trash them.
            </p>

            <div className="shortcut-legend" aria-label="Keyboard shortcuts">
              <span>
                <kbd>0</kbd>
                Hold to talk
              </span>
              <span>
                <kbd>1–9</kbd>
                Play pads
              </span>
            </div>
          </div>

          <div className="record-console">
            <div className="record-orbit" data-recording={activity === "recording"}>
              <button
                type="button"
                className="push-to-talk"
                aria-pressed={activity === "recording"}
                aria-describedby="record-help"
                onPointerDown={(event) => {
                  if (event.pointerType !== "mouse" || event.button === 0) {
                    event.preventDefault();
                    event.currentTarget.setPointerCapture(event.pointerId);
                    void startRecording();
                  }
                }}
                onPointerUp={(event) => {
                  event.preventDefault();
                  stopRecording();
                }}
                onPointerCancel={stopRecording}
                onKeyDown={(event) => {
                  if (
                    (event.key === " " || event.key === "Enter") &&
                    !event.repeat
                  ) {
                    event.preventDefault();
                    void startRecording();
                  }
                }}
                onKeyUp={(event) => {
                  if (event.key === " " || event.key === "Enter") {
                    event.preventDefault();
                    stopRecording();
                  }
                }}
                disabled={
                  isBusy && activity !== "recording" ||
                  storageState === "unavailable" ||
                  !storageLoaded ||
                  emptySlots.length === 0
                }
              >
                <span className="mic-icon">
                  <MicIcon />
                </span>
                <strong>
                  {activity === "recording" ? "Listening" : "Push to talk"}
                </strong>
                <span className="zero-key">0</span>
              </button>
            </div>
            <p id="record-help">
              {emptySlots.length
                ? `${emptySlots.length} empty pad${emptySlots.length === 1 ? "" : "s"} available`
                : "Delete a pad to make room"}
            </p>
          </div>
        </section>

        <section className="control-strip" aria-labelledby="prompt-label">
          <div className="prompt-field">
            <label id="prompt-label" htmlFor="prompt">
              Current prompt
            </label>
            <input
              id="prompt"
              value={prompt}
              onChange={(event) => setPrompt(event.target.value)}
              placeholder="Your spoken prompt appears here"
              spellCheck="true"
            />
          </div>
          <button
            type="button"
            className="generate-button"
            onClick={() => generateForPrompt(prompt)}
            disabled={
              isBusy ||
              !prompt.trim() ||
              emptySlots.length === 0 ||
              storageState === "unavailable"
            }
          >
            Fill {emptySlots.length || 0} empty{" "}
            {emptySlots.length === 1 ? "pad" : "pads"}
          </button>
        </section>

        <section className="activity-panel" aria-label="Generation status">
          <div>
            <span className={`activity-dot activity-${activity}`} />
            <p aria-live="polite" aria-atomic="true">
              {status}
            </p>
          </div>
          {modelProgress > 0 && modelProgress < 1 ? (
            <div className="model-loader">
              <span>{modelProgressPercent}%</span>
              <progress value={modelProgress} max="1">
                {modelProgressPercent}%
              </progress>
            </div>
          ) : null}
          {error ? (
            <p className="error-message" role="alert">
              <span aria-hidden="true">!</span>
              {error}
            </p>
          ) : null}
        </section>

        <section
          id="sound-pads"
          className="pads-section"
          aria-labelledby="pads-title"
          tabIndex={-1}
        >
          <div className="section-heading">
            <div>
              <p className="eyebrow">Persistent local library</p>
              <h2 id="pads-title">Number pads</h2>
            </div>
            <p>
              Generated WAV files live in this site&apos;s private OPFS. A new
              prompt only fills empty pads.
            </p>
          </div>

          <ul className="pad-grid" role="list">
            {SLOT_NUMBERS.map((slot) => {
              const sample = sampleBySlot.get(slot);
              const progress = generationProgress[slot];
              const isPlaying = playingSlot === slot;

              return (
                <li
                  key={slot}
                  className={`pad-card ${sample ? "pad-ready" : "pad-empty"} ${isPlaying ? "pad-playing" : ""}`}
                >
                  <div className="pad-topline">
                    <span className="pad-number">{slot}</span>
                    <span className="pad-state">
                      {sample
                        ? isPlaying
                          ? "Playing"
                          : "Saved"
                        : progress !== undefined
                          ? "Generating"
                          : "Empty"}
                    </span>
                    <button
                      type="button"
                      className="trash-button"
                      onClick={() => requestDelete(slot)}
                      disabled={!sample}
                      aria-label={`Delete sound from pad ${slot}`}
                    >
                      <TrashIcon />
                    </button>
                  </div>

                  <button
                    type="button"
                    className="pad-play"
                    onClick={() => playSlot(slot)}
                    disabled={!sample}
                    aria-label={
                      sample
                        ? `Play pad ${slot}: ${sample.variant}`
                        : `Pad ${slot} is empty`
                    }
                  >
                    <span className="play-disc">
                      <PlayIcon />
                    </span>
                    <Waveform slot={slot} />
                  </button>

                  <div className="pad-copy">
                    <h3>{sample ? sample.variant : "Waiting for a sound"}</h3>
                    <p>
                      {sample
                        ? sample.prompt
                        : progress !== undefined
                          ? `Rendering ${Math.round(progress * 100)}%`
                          : `Press ${slot} after this pad is filled`}
                    </p>
                  </div>

                  <div className="pad-footer">
                    <span>
                      {sample
                        ? formatDuration(sample.duration)
                        : progress !== undefined
                          ? `${Math.round(progress * 100)}%`
                          : "—"}
                    </span>
                    {progress !== undefined && !sample ? (
                      <progress value={progress} max="1">
                        {Math.round(progress * 100)}%
                      </progress>
                    ) : (
                      <span>{sample ? "WAV · OPFS" : "Available"}</span>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </main>

      <footer>
        <p>
          Microphone recordings are discarded after transcription. Generated
          samples remain private to this browser profile.
        </p>
        <p>Best on desktop Chrome or Edge.</p>
      </footer>

      <dialog
        ref={deleteDialogRef}
        className="delete-dialog"
        aria-labelledby="delete-title"
        onClose={() => setPendingDeleteSlot(null)}
      >
        <form method="dialog">
          <span className="dialog-icon" aria-hidden="true">
            <TrashIcon />
          </span>
          <h2 id="delete-title">Delete pad {pendingDeleteSlot}?</h2>
          <p>
            This permanently removes the WAV file from this site&apos;s private
            OPFS storage.
          </p>
          <div className="dialog-actions">
            <button type="submit" value="cancel">
              Keep sound
            </button>
            <button
              type="button"
              className="danger-button"
              onClick={() => void confirmDelete()}
            >
              Delete sound
            </button>
          </div>
        </form>
      </dialog>
    </>
  );
}
